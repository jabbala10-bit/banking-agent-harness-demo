from fastapi.testclient import TestClient
from app.main import app
from app.store import store
from app.audit import clear
from app.harness import Harness
import pytest

client=TestClient(app)
@pytest.fixture(autouse=True)
def reset():
    store.reset(); clear()
    yield

def test_ambiguous_beneficiary():
    r=Harness().initiate("s1","John",10000)
    assert r.status=="NEEDS_CLARIFICATION" and len(r.data["matches"])==2
    assert not store.transactions

def test_blocked_beneficiary():
    r=Harness().initiate("s1","Nick Anderson",25000)
    assert r.status=="REJECTED" and r.data["code"]=="BENEFICIARY_INACTIVE"

def test_negative_amount():
    assert Harness().initiate("s1","John Smith",-1).data["code"]=="INVALID_AMOUNT"

def test_daily_limit():
    assert Harness().initiate("s1","John Smith",80000).data["code"]=="DAILY_LIMIT_EXCEEDED"

def test_requires_approval_and_verifies():
    h=Harness(); r=h.initiate("s1","John Smith",10000)
    assert r.status=="PENDING_CONFIRMATION" and store.account.balance==200000
    done=h.approve("s1",r.data["transaction_id"])
    assert done.status=="COMPLETED" and done.data["verified"] is True
    assert store.account.balance==190000
    assert h.approve("s1",r.data["transaction_id"]).status=="REJECTED"

def test_session_binding():
    h=Harness(); r=h.initiate("s1","John Smith",10000)
    assert h.approve("s2",r.data["transaction_id"]).status=="REJECTED"
    assert store.account.balance==200000

def test_transfer_limit():
    h=Harness()
    for name,amount in [("John Smith",10000),("Priya Shah",20000)]:
        r=h.initiate("s1",name,amount)
        assert h.approve("s1",r.data["transaction_id"]).status=="COMPLETED"
    r=h.initiate("s1","John Smith",1000)
    assert r.status=="REJECTED" and r.data["code"]=="SESSION_TRANSFER_LIMIT"

def test_chat_api():
    r=client.post("/api/chat",json={"session_id":"api","message":"What is my balance?"})
    assert r.status_code==200 and "200,000" in r.json()["answer"]
