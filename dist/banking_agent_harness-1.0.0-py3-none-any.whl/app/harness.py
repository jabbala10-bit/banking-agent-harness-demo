from .audit import emit
from .config import MAX_TRANSFERS_PER_SESSION
from .models import Transaction, Result, new_id, now
from .store import store

class PolicyService:
    def validate(self, sid, name, amount):
        name = name.strip()
        if not name: return Result(status="REJECTED", message="Beneficiary name is required.", data={"code":"BENEFICIARY_REQUIRED"})
        if amount <= 0: return Result(status="REJECTED", message="Amount must be greater than zero.", data={"code":"INVALID_AMOUNT"})
        if round(amount, 2) != amount: return Result(status="REJECTED", message="Amount can have at most two decimal places.", data={"code":"INVALID_AMOUNT_PRECISION"})
        a = store.account
        if not a.active: return Result(status="REJECTED", message="Source account is inactive.", data={"code":"SOURCE_ACCOUNT_INACTIVE"})
        exact = [b for b in store.beneficiaries if b.name.casefold() == name.casefold()]
        matches = exact or [b for b in store.beneficiaries if name.casefold() in b.name.casefold()]
        if not matches: return Result(status="REJECTED", message="Beneficiary not found.", data={"code":"BENEFICIARY_NOT_FOUND"})
        if len(matches) > 1:
            return Result(status="NEEDS_CLARIFICATION", message="Multiple beneficiaries match; ask the user to choose.", data={"code":"AMBIGUOUS_BENEFICIARY","matches":[{"name":b.name,"suffix":b.suffix,"active":b.active} for b in matches]})
        b = matches[0]
        if not b.active: return Result(status="REJECTED", message="Beneficiary account is blocked or inactive.", data={"code":"BENEFICIARY_INACTIVE","beneficiary":b.name})
        if amount > a.balance: return Result(status="REJECTED", message="Insufficient available balance.", data={"code":"INSUFFICIENT_FUNDS"})
        if a.transferred_today + amount > a.daily_limit:
            return Result(status="REJECTED", message="Daily transfer limit would be exceeded.", data={"code":"DAILY_LIMIT_EXCEEDED"})
        if store.session(sid).completed_count >= MAX_TRANSFERS_PER_SESSION:
            return Result(status="REJECTED", message="Maximum successful transfers for this chat session reached.", data={"code":"SESSION_TRANSFER_LIMIT","max":MAX_TRANSFERS_PER_SESSION})
        return Result(status="VALIDATED", message="Policy checks passed.", data={"beneficiary_id":b.id,"beneficiary":b.name,"suffix":b.suffix})

class Verifier:
    def verify(self, txn):
        if txn.status == "COMPLETED" and txn.verification_message:
            emit("TRANSACTION_VERIFIED", txn.session_id, txn.id, {"status":txn.status})
            return Result(status="COMPLETED", message="Transfer completed and verified by the mock ledger.", data={"verified":True})
        if txn.status in ("FAILED","REJECTED"):
            return Result(status=txn.status, message=f"Transfer status verified: {txn.status}.", data={"verified":True})
        return Result(status="PENDING", message="Outcome is not confirmed. Do not claim success or retry blindly.", data={"verified":False})

class Harness:
    def __init__(self):
        self.policy = PolicyService()
        self.verifier = Verifier()

    def initiate(self, sid, name, amount):
        result = self.policy.validate(sid, name, float(amount))
        emit("TRANSFER_VALIDATION", sid, details={"status":result.status,"code":result.data.get("code"),"amount":amount,"beneficiary_query":name})
        if result.status != "VALIDATED": return result
        with store.lock:
            # Re-check execution count under lock.
            if store.session(sid).completed_count >= MAX_TRANSFERS_PER_SESSION:
                return Result(status="REJECTED", message="Session transfer limit reached.", data={"code":"SESSION_TRANSFER_LIMIT"})
            b = store.beneficiary(result.data["beneficiary_id"])
            txn = Transaction(id=new_id("TXN"), session_id=sid, beneficiary_id=b.id,
                              beneficiary=b.name, suffix=b.suffix, amount=float(amount))
            store.transactions[txn.id] = txn
            store.session(sid).pending_ids.append(txn.id)
        emit("TRANSFER_INITIATED", sid, txn.id, {"amount":amount,"beneficiary":b.name,"status":txn.status})
        return Result(status="PENDING_CONFIRMATION", message="Validated; explicit approval is required. No funds moved yet.",
                      data={"transaction_id":txn.id,"amount":txn.amount,"beneficiary":b.name,"suffix":b.suffix,"status":txn.status,"requires_confirmation":True})

    def approve(self, sid, tid):
        with store.lock:
            txn = store.transactions.get(tid)
            if not txn or txn.session_id != sid:
                return Result(status="REJECTED", message="Transaction not found for this session.", data={"code":"TRANSACTION_NOT_FOUND"})
            if txn.status != "AWAITING_APPROVAL" or txn.approval_used:
                return Result(status="REJECTED", message="Transaction is no longer awaiting approval.", data={"code":"INVALID_TRANSACTION_STATE","status":txn.status})
            # Revalidate immediately before execution.
            check = self.policy.validate(sid, txn.beneficiary, txn.amount)
            if check.status != "VALIDATED":
                txn.status = "REJECTED"; txn.updated_at = now()
                emit("TRANSFER_REJECTED_AT_APPROVAL", sid, tid, {"code":check.data.get("code")})
                return check
            txn.approval_used = True; txn.status = "EXECUTING"; txn.updated_at = now()
            emit("TRANSFER_APPROVED", sid, tid, {"amount":txn.amount,"beneficiary":txn.beneficiary})
            a = store.account; b = store.beneficiary(txn.beneficiary_id)
            if not b or not b.active or not a.active or txn.amount > a.balance or a.transferred_today + txn.amount > a.daily_limit:
                txn.status = "FAILED"; txn.verification_message = "Execution-time invariant failed."
            else:
                a.balance -= txn.amount; a.transferred_today += txn.amount
                txn.status = "COMPLETED"; txn.verification_message = "Mock ledger updated."
                store.session(sid).completed_count += 1
            txn.updated_at = now()
            verified = self.verifier.verify(txn)
            if tid in store.session(sid).pending_ids: store.session(sid).pending_ids.remove(tid)
            emit("TRANSFER_EXECUTION_RESULT", sid, tid, {"status":txn.status,"verified":verified.data.get("verified")})
            return Result(status=txn.status, message=verified.message, data={"transaction_id":tid,"status":txn.status,"verified":verified.data.get("verified"),"balance":a.balance})

    def reject(self, sid, tid):
        with store.lock:
            txn = store.transactions.get(tid)
            if not txn or txn.session_id != sid:
                return Result(status="REJECTED", message="Transaction not found for this session.", data={"code":"TRANSACTION_NOT_FOUND"})
            if txn.status != "AWAITING_APPROVAL":
                return Result(status="REJECTED", message="Only pending approvals can be rejected.", data={"code":"INVALID_TRANSACTION_STATE"})
            txn.status = "REJECTED"; txn.updated_at = now()
            if tid in store.session(sid).pending_ids: store.session(sid).pending_ids.remove(tid)
            emit("TRANSFER_REJECTED_BY_USER", sid, tid)
            return Result(status="REJECTED", message="Transfer rejected. No funds were moved.", data={"transaction_id":tid})
