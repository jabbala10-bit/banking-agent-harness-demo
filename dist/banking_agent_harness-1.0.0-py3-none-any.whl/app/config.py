import os
from dotenv import load_dotenv
load_dotenv()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "").strip()
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
MAX_TRANSFERS_PER_SESSION = int(os.getenv("MAX_TRANSFERS_PER_SESSION", "2"))
MAX_TOOL_CALLS_PER_TURN = int(os.getenv("MAX_TOOL_CALLS_PER_TURN", "6"))
AUDIT_PATH = os.getenv("AUDIT_PATH", "data/audit.jsonl")
